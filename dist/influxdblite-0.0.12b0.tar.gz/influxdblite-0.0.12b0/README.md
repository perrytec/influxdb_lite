# InfluxDB Lite #

## Overview ##

InfluxDB Lite is a basic ORM for InfluxDB OSS 2.x. 
InfluxDB lite builds on top of the InfluxDB python client library.

## Dependencies ##
influxdb-client

## Licence & Copyright ##

Licensed under the [MIT License](LICENSE).